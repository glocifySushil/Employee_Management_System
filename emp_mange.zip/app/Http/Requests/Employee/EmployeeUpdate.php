<?php

namespace App\Http\Requests\Employee;

use Illuminate\Foundation\Http\FormRequest;

class EmployeeUpdate extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email'  => 'email|unique:users',
            'employee_id' => 'required|unique:users',
            'contact_number' => 'required|numeric|digits:10',
            'emergency_contact_number' => 'required|numeric|digits:10',

        ];
    }
}
